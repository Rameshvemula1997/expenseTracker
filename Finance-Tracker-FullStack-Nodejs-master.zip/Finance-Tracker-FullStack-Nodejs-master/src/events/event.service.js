const { EventEmitter } = require("events");


const eventBridge = new EventEmitter();

module.exports = eventBridge;
